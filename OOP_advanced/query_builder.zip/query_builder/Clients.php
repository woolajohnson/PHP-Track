<?php
class Clients extends QueryBuilder {
}
?>