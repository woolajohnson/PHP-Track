<?php
class Sites extends QueryBuilder {
}
?>