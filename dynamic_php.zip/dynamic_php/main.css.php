<?php
 header('Content-type: text/css');
?>

p {
    font-size: <?= rand(15, 80) ?>px;
    color: <?= '#' . rand(000000, 999999) ?>;
}
em {
    font-size: <?= rand(15, 80) ?>px;
    color: <?= '#' . rand(000000, 999999) ?>;
}

